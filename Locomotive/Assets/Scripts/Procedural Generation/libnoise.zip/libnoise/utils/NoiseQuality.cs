namespace noise
{
    public enum NoiseQuality
    {
        QUALITY_FAST = 0,
        QUALITY_STD = 1,
        QUALITY_BEST = 2
    };
}